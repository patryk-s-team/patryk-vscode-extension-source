const fs = require("fs");
const os = require("os");
const path = require("path");
const vscode = require("vscode");

function quoteShell(value) {
  return `"${String(value).replace(/"/g, '\\"')}"`;
}

function quotePythonCommand(command) {
  if (!command) {
    return "";
  }

  const trimmed = command.trim();
  if (trimmed.startsWith('"') || trimmed.startsWith("'")) {
    return trimmed;
  }

  if (/\s/.test(trimmed) && /\.(bat|cmd|exe)$/i.test(trimmed)) {
    return quoteShell(trimmed);
  }

  return trimmed;
}

function findPythonCommand(configuredPath) {
  if (configuredPath && configuredPath.trim()) {
    return configuredPath.trim();
  }

  const candidates = [];
  if (process.platform === "win32") {
    candidates.push(
      path.join(
        os.homedir(),
        ".cache",
        "codex-runtimes",
        "codex-primary-runtime",
        "dependencies",
        "python",
        "python.exe"
      )
    );
    candidates.push("py -3");
  } else {
    candidates.push("python3");
  }
  candidates.push("python");

  for (const candidate of candidates) {
    if (candidate.includes(path.sep) && fs.existsSync(candidate)) {
      return candidate;
    }
  }

  return candidates[0];
}

function runWindowScript(context, filePath) {
  const runtimePath = context.asAbsolutePath("runtime.py");
  if (!fs.existsSync(runtimePath)) {
    vscode.window.showErrorMessage(`WindowScript runtime is missing: ${runtimePath}`);
    return;
  }

  const pythonPath = vscode.workspace.getConfiguration("windowscript").get("pythonPath", "");
  const pythonCommand = quotePythonCommand(findPythonCommand(pythonPath));

  const terminal = vscode.window.createTerminal({
    name: "WindowScript Runtime",
    cwd: path.dirname(filePath),
  });

  terminal.show(true);
  terminal.sendText(`${pythonCommand} ${quoteShell(runtimePath)} ${quoteShell(filePath)}`);
}

async function runCurrentFile(context) {
  const editor = vscode.window.activeTextEditor;

  if (!editor || editor.document.languageId !== "windowscript") {
    vscode.window.showErrorMessage("Open a WindowScript (.ws) file before running.");
    return;
  }

  if (editor.document.isUntitled) {
    vscode.window.showErrorMessage("Save the WindowScript file before running it.");
    return;
  }

  await editor.document.save();
  runWindowScript(context, editor.document.uri.fsPath);
}

function playDemoGame(context) {
  const gamePath = context.asAbsolutePath(path.join("examples", "star_miner.ws"));
  if (!fs.existsSync(gamePath)) {
    vscode.window.showErrorMessage(`WindowScript demo game is missing: ${gamePath}`);
    return;
  }

  runWindowScript(context, gamePath);
}

function activate(context) {
  context.subscriptions.push(
    vscode.commands.registerCommand("windowscript.runFile", () => runCurrentFile(context)),
    vscode.commands.registerCommand("windowscript.playDemoGame", () => playDemoGame(context))
  );
}

function deactivate() {}

module.exports = {
  activate,
  deactivate,
};
