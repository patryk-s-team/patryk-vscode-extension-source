require windowmaker
require math
require buttonmaker
require clickybundle

windowmaker='createWindow1'

Inside='Window1':
createButton='Button1'='Click me!'

whenButtonPressed='createScore='changeScore+1'appearingText:Score:{Score}'

whenScore='10000':END_WINDOW_SCRIPT