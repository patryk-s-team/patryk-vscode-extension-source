#!/usr/bin/env python3
"""Small Python runtime for WindowScript files."""

from __future__ import annotations

import argparse
import random
import re
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


class WindowScriptError(Exception):
    """Raised when a WindowScript file cannot be parsed or run."""


@dataclass
class Action:
    kind: str
    args: tuple[Any, ...] = ()


@dataclass
class ButtonSpec:
    button_id: str
    text: str
    actions: list[Action] = field(default_factory=list)


@dataclass
class ScoreRule:
    name: str
    comparator: str
    target: int
    action: str
    message: str = ""


@dataclass
class TextAndNumberSpec:
    text_id: str
    template: str


@dataclass
class InputSpec:
    input_id: str
    default: str


@dataclass
class MessageSpec:
    message_id: str
    template: str


@dataclass
class ProgressSpec:
    name: str
    minimum: int
    maximum: int


@dataclass
class Program:
    source: Path
    window_id: str = "Window1"
    title: str = "WindowScript"
    numbers: dict[str, int] = field(default_factory=dict)
    texts: list[TextAndNumberSpec] = field(default_factory=list)
    text_and_numbers: list[TextAndNumberSpec] = field(default_factory=list)
    inputs: list[InputSpec] = field(default_factory=list)
    messages: list[MessageSpec] = field(default_factory=list)
    progress_bars: list[ProgressSpec] = field(default_factory=list)
    buttons: list[ButtonSpec] = field(default_factory=list)
    score_rules: list[ScoreRule] = field(default_factory=list)
    required_modules: list[str] = field(default_factory=list)
    game: str | None = None
    used_features: dict[str, set[int]] = field(default_factory=dict)

    def button_by_id(self, button_id: str) -> ButtonSpec | None:
        for button in self.buttons:
            if button.button_id == button_id:
                return button
        return None

    def use_feature(self, feature: str, line_number: int) -> None:
        self.used_features.setdefault(feature, set()).add(line_number)

    def has_require(self, module: str) -> bool:
        return module.lower() in {item.lower() for item in self.required_modules}


def strip_comment(line: str) -> str:
    in_single = False
    for index, char in enumerate(line):
        if char == "'":
            in_single = not in_single
        elif char == "#" and not in_single:
            return line[:index]
    return line


def unquote(value: str) -> str:
    value = value.strip()
    if len(value) >= 2 and value[0] == "'" and value[-1] == "'":
        return value[1:-1]
    return value


def parse_create_button(line: str, line_number: int) -> ButtonSpec:
    match = re.fullmatch(r"createButton\s*=\s*'([^']+)'\s*=\s*'([^']*)'", line)
    if not match:
        raise WindowScriptError(
            f"Line {line_number}: expected createButton='ButtonId'='Button text'"
        )
    return ButtonSpec(button_id=match.group(1), text=match.group(2))


def parse_create_number(line: str, line_number: int) -> tuple[str, int]:
    match = re.fullmatch(r"createNumber\s*=\s*'([^']+)'\s*=\s*'?(-?\d+)'?", line)
    if not match:
        raise WindowScriptError(
            f"Line {line_number}: expected createNumber='Name'=10"
        )
    return match.group(1), int(match.group(2))


def parse_create_text_and_number(line: str, line_number: int) -> TextAndNumberSpec:
    match = re.fullmatch(r"createTextAndNumber\s*=\s*'([^']+)'\s*=\s*'([^']*)'", line)
    if not match:
        raise WindowScriptError(
            f"Line {line_number}: expected createTextAndNumber='Id'='Health: {{Health}}'"
        )
    return TextAndNumberSpec(text_id=match.group(1), template=match.group(2))


def parse_create_text(line: str, line_number: int) -> TextAndNumberSpec:
    match = re.fullmatch(r"createText\s*=\s*'([^']+)'\s*=\s*'([^']*)'", line)
    if not match:
        raise WindowScriptError(
            f"Line {line_number}: expected createText='Id'='Text'"
        )
    return TextAndNumberSpec(text_id=match.group(1), template=match.group(2))


def parse_create_input(line: str, line_number: int) -> InputSpec:
    match = re.fullmatch(r"createInput\s*=\s*'([^']+)'\s*=\s*'([^']*)'", line)
    if not match:
        raise WindowScriptError(
            f"Line {line_number}: expected createInput='Name'='Default text'"
        )
    return InputSpec(input_id=match.group(1), default=match.group(2))


def parse_create_message(line: str, line_number: int) -> MessageSpec:
    match = re.fullmatch(r"createMessage\s*=\s*'([^']+)'\s*=\s*'([^']*)'", line)
    if not match:
        raise WindowScriptError(
            f"Line {line_number}: expected createMessage='Log'='Starting message'"
        )
    return MessageSpec(message_id=match.group(1), template=match.group(2))


def parse_create_progress(line: str, line_number: int) -> ProgressSpec:
    match = re.fullmatch(r"createProgress\s*=\s*'([^']+)'\s*=\s*(-?\d+)\.\.(-?\d+)", line)
    if not match:
        raise WindowScriptError(
            f"Line {line_number}: expected createProgress='Health'=0..10"
        )

    minimum = int(match.group(2))
    maximum = int(match.group(3))
    if maximum <= minimum:
        raise WindowScriptError(f"Line {line_number}: progress maximum must be greater than minimum")

    return ProgressSpec(name=match.group(1), minimum=minimum, maximum=maximum)


def parse_inside(line: str, line_number: int) -> str:
    match = re.fullmatch(r"Inside\s*=\s*'([^']+)'\s*:?", line)
    if not match:
        raise WindowScriptError(f"Line {line_number}: expected Inside='WindowName':")
    return match.group(1)


def parse_windowmaker(line: str) -> str:
    return unquote(line.split("=", 1)[1])


def parse_score_rule(line: str, line_number: int) -> ScoreRule:
    match = re.fullmatch(
        r"when([A-Za-z_][A-Za-z0-9_]*)\s*(>=|<=|==|>|<|=)\s*'(-?\d+)'\s*:\s*([A-Za-z_][A-Za-z0-9_]*)(?:\s*=\s*'([^']*)')?",
        line,
    )
    if not match:
        raise WindowScriptError(
            f"Line {line_number}: expected whenScore='100':END_WINDOW_SCRIPT or whenHealth<='0':LOSE='message'"
        )
    comparator = ">=" if match.group(2) == "=" else match.group(2)
    return ScoreRule(
        name=match.group(1),
        comparator=comparator,
        target=int(match.group(3)),
        action=match.group(4),
        message=match.group(5) or "",
    )


def parse_game(line: str, line_number: int) -> str:
    match = re.fullmatch(r"game\s*=\s*'([^']+)'", line)
    if not match:
        raise WindowScriptError(f"Line {line_number}: expected game='star_miner'")
    return match.group(1).strip().lower().replace("-", "_").replace(" ", "_")


def find_target_button(program: Program, line: str) -> tuple[ButtonSpec, str]:
    payload = line.split("=", 1)[1].strip()
    targeted = re.match(r"'([^']+)'\s*=\s*(.+)$", payload)

    if targeted:
        button = program.button_by_id(targeted.group(1))
        if button is not None:
            return button, targeted.group(2).strip()

    if not program.buttons:
        raise WindowScriptError("whenButtonPressed must come after createButton")

    return program.buttons[-1], payload


def parse_actions(payload: str, line_number: int) -> list[Action]:
    compact = unquote(payload).replace("'", "").strip()
    ordered_actions: list[tuple[int, Action]] = []

    def add_matches(pattern: str, factory: Any) -> None:
        for match in re.finditer(pattern, compact):
            ordered_actions.append((match.start(), factory(match)))

    add_matches(
        r"\bcreate([A-Za-z_][A-Za-z0-9_]*)\b",
        lambda match: Action("ensure_variable", (match.group(1), 0)),
    )
    add_matches(
        r"\brandom([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(-?\d+)\.\.(-?\d+)",
        lambda match: Action(
            "random_variable",
            (match.group(1), int(match.group(2)), int(match.group(3))),
        ),
    )
    add_matches(
        r"\bset([A-Za-z_][A-Za-z0-9_]*)FromInput\b",
        lambda match: Action("set_variable_from_input", (match.group(1),)),
    )
    add_matches(
        r"\bset([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(-?\d+|\{[A-Za-z_][A-Za-z0-9_]*\})",
        lambda match: Action("set_variable", (match.group(1), match.group(2))),
    )
    add_matches(
        r"\bchange([A-Za-z_][A-Za-z0-9_]*)\s*([+-])\s*(\d+|\{[A-Za-z_][A-Za-z0-9_]*\})",
        lambda match: Action("change_variable", (match.group(1), match.group(2), match.group(3))),
    )

    message_index = compact.find("message:")
    if message_index >= 0:
        ordered_actions.append((message_index, Action("message", (compact[message_index + 8 :].strip(),))))

    appearing_index = compact.find("appearingText:")
    if appearing_index >= 0:
        ordered_actions.append((appearing_index, Action("show_text", (compact[appearing_index + 14 :].strip(),))))

    end_index = compact.find("END_WINDOW_SCRIPT")
    if end_index >= 0:
        ordered_actions.append((end_index, Action("end", ())))

    if not ordered_actions:
        raise WindowScriptError(f"Line {line_number}: no runnable action found")

    return [action for _, action in sorted(ordered_actions, key=lambda item: item[0])]


def validate_requires(program: Program) -> None:
    requirements = {
        "window": ("windowmaker", "window features need require windowmaker"),
        "button": ("buttonmaker", "button features need require buttonmaker"),
        "click": ("clickybundle", "button click handlers need require clickybundle"),
        "math": ("math", "number and rule features need require math"),
        "game": ("game", "built-in games need require game"),
    }

    for feature, (module, message) in requirements.items():
        if feature not in program.used_features or program.has_require(module):
            continue

        lines = ", ".join(str(line) for line in sorted(program.used_features[feature]))
        raise WindowScriptError(f"Line {lines}: {message}")


def parse_file(source: Path) -> Program:
    program = Program(source=source)

    for line_number, raw_line in enumerate(source.read_text(encoding="utf-8-sig").splitlines(), 1):
        line = strip_comment(raw_line).strip()
        if not line:
            continue

        if line.startswith("require "):
            program.required_modules.append(line.split(None, 1)[1].strip())
        elif line.startswith("windowmaker"):
            program.use_feature("window", line_number)
            program.window_id = parse_windowmaker(line)
        elif line.startswith("Inside"):
            program.use_feature("window", line_number)
            program.title = parse_inside(line, line_number)
        elif line.startswith("createNumber"):
            program.use_feature("math", line_number)
            name, value = parse_create_number(line, line_number)
            program.numbers[name] = value
        elif line.startswith("createTextAndNumber"):
            program.use_feature("math", line_number)
            program.text_and_numbers.append(parse_create_text_and_number(line, line_number))
        elif line.startswith("createText"):
            program.use_feature("window", line_number)
            program.texts.append(parse_create_text(line, line_number))
        elif line.startswith("createInput"):
            program.use_feature("window", line_number)
            program.inputs.append(parse_create_input(line, line_number))
        elif line.startswith("createMessage"):
            program.use_feature("window", line_number)
            program.messages.append(parse_create_message(line, line_number))
        elif line.startswith("createProgress"):
            program.use_feature("math", line_number)
            program.progress_bars.append(parse_create_progress(line, line_number))
        elif line.startswith("createButton"):
            program.use_feature("button", line_number)
            program.buttons.append(parse_create_button(line, line_number))
        elif line.startswith("game"):
            program.use_feature("game", line_number)
            program.use_feature("math", line_number)
            program.game = parse_game(line, line_number)
        elif line.startswith("whenButtonPressed"):
            program.use_feature("button", line_number)
            program.use_feature("click", line_number)
            button, payload = find_target_button(program, line)
            actions = parse_actions(payload, line_number)
            if any(
                action.kind
                in {"ensure_variable", "random_variable", "set_variable", "change_variable"}
                for action in actions
            ):
                program.use_feature("math", line_number)
            button.actions.extend(actions)
        elif line.startswith("when") and ":" in line:
            program.use_feature("math", line_number)
            program.score_rules.append(parse_score_rule(line, line_number))
        elif line == "END_WINDOW_SCRIPT":
            break
        else:
            raise WindowScriptError(f"Line {line_number}: unknown statement: {line}")

    if (
        program.game
        or program.buttons
        or program.numbers
        or program.texts
        or program.text_and_numbers
        or program.inputs
        or program.messages
        or program.progress_bars
    ):
        program.use_feature("window", 1)

    validate_requires(program)
    return program


class TkRuntime:
    def __init__(self, program: Program) -> None:
        try:
            import tkinter as tk
            from tkinter import ttk
        except ImportError as exc:
            raise WindowScriptError("Python tkinter is required to run WindowScript windows.") from exc

        self.tk = tk
        self.ttk = ttk
        self.program = program
        self.variables: dict[str, Any] = {}
        self.text_labels: dict[str, Any] = {}
        self.label_templates: dict[str, str] = {}
        self.input_widgets: dict[str, Any] = {}
        self.progress_widgets: dict[str, tuple[Any, Any, int, int]] = {}
        self.message_lines: list[str] = []
        self.message_label: Any | None = None
        self.action_buttons: list[Any] = []
        self.current_row = 0
        self.finished = False
        self.root = tk.Tk()
        self.root.title(program.title)
        self.root.minsize(420, 220)

        self.frame = ttk.Frame(self.root, padding=16)
        self.frame.grid(row=0, column=0, sticky="nsew")
        self.root.columnconfigure(0, weight=1)
        self.root.rowconfigure(0, weight=1)
        self.frame.columnconfigure(0, weight=1)
        self.frame.columnconfigure(1, weight=1)

    def render_template(self, template: str) -> str:
        def replace(match: re.Match[str]) -> str:
            name = match.group(1)
            return str(self.variables.get(name, 0))

        return re.sub(r"\{([A-Za-z_][A-Za-z0-9_]*)\}", replace, template)

    def ensure_label(self, key: str, template: str | None = None) -> Any:
        if template is None:
            template = key
        self.label_templates[key] = template
        label = self.text_labels.get(key)
        if label is None:
            label = self.ttk.Label(self.frame, anchor="center", font=("", 12))
            label.grid(row=self.current_row, column=0, columnspan=2, sticky="ew", pady=(0, 10))
            self.text_labels[key] = label
            self.current_row += 1
        return label

    def ensure_message_label(self) -> Any:
        if self.message_label is None:
            self.message_label = self.ttk.Label(
                self.frame,
                anchor="w",
                justify="left",
                wraplength=520,
            )
            self.message_label.grid(
                row=self.current_row,
                column=0,
                columnspan=2,
                sticky="ew",
                pady=(2, 12),
            )
            self.current_row += 1
        return self.message_label

    def refresh_labels(self) -> None:
        for key, label in self.text_labels.items():
            label.configure(text=self.render_template(self.label_templates[key]))

    def refresh_progress(self) -> None:
        for name, (label, bar, minimum, maximum) in self.progress_widgets.items():
            value = self.number_value(name)
            clipped = max(minimum, min(maximum, value))
            label.configure(text=f"{name}: {value}/{maximum}")
            bar.configure(value=clipped - minimum)

    def refresh_messages(self) -> None:
        if self.message_label is not None:
            self.message_label.configure(text="\n".join(self.message_lines[-6:]))

    def refresh_all(self) -> None:
        self.refresh_labels()
        self.refresh_progress()
        self.refresh_messages()

    def number_value(self, name: str) -> int:
        value = self.variables.get(name, 0)
        try:
            return int(value)
        except (TypeError, ValueError):
            return 0

    def action_value(self, token: str) -> int:
        if token.startswith("{") and token.endswith("}"):
            return self.number_value(token[1:-1])
        return int(token)

    def add_message(self, template: str) -> None:
        self.ensure_message_label()
        self.message_lines.append(self.render_template(template))
        self.refresh_messages()

    def create_input(self, spec: InputSpec) -> None:
        label = self.ttk.Label(self.frame, text=spec.input_id, anchor="w")
        label.grid(row=self.current_row, column=0, sticky="w", pady=4, padx=(0, 8))
        entry = self.ttk.Entry(self.frame)
        entry.insert(0, spec.default)
        entry.grid(row=self.current_row, column=1, sticky="ew", pady=4)
        self.input_widgets[spec.input_id] = entry
        self.variables.setdefault(spec.input_id, spec.default)
        self.current_row += 1

    def create_progress(self, spec: ProgressSpec) -> None:
        label = self.ttk.Label(self.frame, anchor="w")
        label.grid(row=self.current_row, column=0, columnspan=2, sticky="ew", pady=(6, 2))
        self.current_row += 1
        bar = self.ttk.Progressbar(
            self.frame,
            maximum=spec.maximum - spec.minimum,
            mode="determinate",
        )
        bar.grid(row=self.current_row, column=0, columnspan=2, sticky="ew", pady=(0, 8))
        self.progress_widgets[spec.name] = (label, bar, spec.minimum, spec.maximum)
        self.current_row += 1

    def safe_run_actions(self, actions: list[Action]) -> None:
        try:
            self.run_actions(actions)
        except WindowScriptError as exc:
            self.add_message(f"Error: {exc}")

    def run_actions(self, actions: list[Action]) -> None:
        if self.finished:
            return

        for action in actions:
            if action.kind == "ensure_variable":
                name, default = action.args
                self.variables.setdefault(name, default)
            elif action.kind == "random_variable":
                name, low, high = action.args
                if high < low:
                    low, high = high, low
                self.variables[name] = random.randint(low, high)
            elif action.kind == "set_variable":
                name, token = action.args
                self.variables[name] = self.action_value(token)
            elif action.kind == "set_variable_from_input":
                (name,) = action.args
                widget = self.input_widgets.get(name)
                if widget is None:
                    raise WindowScriptError(f"set{name}FromInput needs createInput='{name}'")
                self.variables[name] = widget.get()
            elif action.kind == "change_variable":
                name, operator, amount = action.args
                delta = self.action_value(amount)
                if operator == "-":
                    delta = -delta
                self.variables[name] = self.number_value(name) + delta
            elif action.kind == "show_text":
                (template,) = action.args
                self.ensure_label(template)
            elif action.kind == "message":
                (template,) = action.args
                self.add_message(template)
            elif action.kind == "end":
                self.root.destroy()
                return

        self.refresh_all()
        self.check_score_rules()
        self.refresh_all()

    def check_score_rules(self) -> None:
        for rule in self.program.score_rules:
            value = self.number_value(rule.name)
            if not self.rule_matches(value, rule):
                continue

            action = rule.action.upper()
            if action == "END_WINDOW_SCRIPT":
                self.root.destroy()
                return
            if action in {"WIN", "LOSE"}:
                self.finish(action == "WIN", rule.message)
                return
            raise WindowScriptError(f"Unknown rule action: {rule.action}")

    def rule_matches(self, value: int, rule: ScoreRule) -> bool:
        if rule.comparator == ">=":
            return value >= rule.target
        if rule.comparator == "<=":
            return value <= rule.target
        if rule.comparator == ">":
            return value > rule.target
        if rule.comparator == "<":
            return value < rule.target
        if rule.comparator == "==":
            return value == rule.target
        return False

    def finish(self, won: bool, message: str) -> None:
        self.finished = True
        fallback = "You win." if won else "You lose."
        self.add_message(message or fallback)
        for button in self.action_buttons:
            button.configure(state="disabled")

    def build(self) -> None:
        self.variables.update(self.program.numbers)

        for spec in self.program.inputs:
            self.variables.setdefault(spec.input_id, spec.default)

        for button in self.program.buttons:
            for action in button.actions:
                if action.kind == "ensure_variable":
                    name, default = action.args
                    self.variables.setdefault(name, default)

        for spec in self.program.texts:
            self.ensure_label(spec.text_id, spec.template)

        for spec in self.program.text_and_numbers:
            self.ensure_label(spec.text_id, spec.template)

        for button in self.program.buttons:
            for action in button.actions:
                if action.kind == "show_text":
                    (template,) = action.args
                    self.ensure_label(template)

        for spec in self.program.inputs:
            self.create_input(spec)

        for spec in self.program.progress_bars:
            self.create_progress(spec)

        for spec in self.program.messages:
            self.message_lines.append(self.render_template(spec.template))

        if self.message_lines:
            self.ensure_message_label()

        self.refresh_all()
        for index, button in enumerate(self.program.buttons):
            widget = self.ttk.Button(
                self.frame,
                text=button.text,
                command=lambda current=button: self.safe_run_actions(current.actions),
            )
            widget.grid(row=self.current_row + index, column=0, columnspan=2, sticky="ew", pady=4)
            self.action_buttons.append(widget)
        self.current_row += len(self.program.buttons)

    def run(self) -> None:
        self.build()
        self.root.mainloop()


class StarMinerGame:
    cargo_goal = 50
    fuel_goal = 8
    max_hull = 8
    max_shield = 5

    def __init__(self, program: Program) -> None:
        try:
            import tkinter as tk
        except ImportError as exc:
            raise WindowScriptError("Python tkinter is required to run Star Miner.") from exc

        self.tk = tk
        self.program = program
        self.root = tk.Tk()
        self.root.title("Star Miner")
        self.root.geometry("760x640")
        self.root.minsize(680, 560)
        self.root.configure(bg="#0b1220")

        self.canvas = tk.Canvas(
            self.root,
            width=720,
            height=320,
            bg="#06101f",
            bd=0,
            highlightthickness=0,
        )
        self.status = tk.Label(
            self.root,
            bg="#0b1220",
            fg="#e6edf7",
            font=("Segoe UI", 12, "bold"),
            justify="left",
        )
        self.goal = tk.Label(
            self.root,
            bg="#0b1220",
            fg="#a7f3d0",
            font=("Segoe UI", 10),
            text=f"Goal: bring home {self.cargo_goal} crystals and {self.fuel_goal} fuel.",
        )
        self.log_label = tk.Label(
            self.root,
            bg="#111827",
            fg="#d1d5db",
            font=("Consolas", 10),
            anchor="nw",
            justify="left",
            padx=12,
            pady=10,
            wraplength=700,
        )
        self.controls = tk.Frame(self.root, bg="#0b1220")

        self.buttons: dict[str, Any] = {}
        self.stars: list[dict[str, float]] = []
        self.logs: list[str] = []
        self.tick = 0
        self.flash = 0
        self.game_over = False
        self.reset_state()

    def reset_state(self) -> None:
        self.crystals = 0
        self.fuel = 7
        self.hull = self.max_hull
        self.shield = 3
        self.turn = 1
        self.scan_bonus = 0
        self.game_over = False
        self.flash = 0
        self.logs = [
            "You are alone in the belt. Mine crystals, keep the ship alive, then jump home."
        ]
        self.stars = [
            {
                "x": random.randint(0, 720),
                "y": random.randint(0, 320),
                "speed": random.uniform(0.4, 1.8),
                "size": random.choice([1, 1, 2]),
            }
            for _ in range(95)
        ]

    def build(self) -> None:
        self.canvas.pack(fill="x", padx=20, pady=(18, 12))
        self.status.pack(fill="x", padx=20)
        self.goal.pack(fill="x", padx=20, pady=(2, 12))
        self.log_label.pack(fill="both", expand=True, padx=20, pady=(0, 14))
        self.controls.pack(fill="x", padx=20, pady=(0, 18))

        specs = [
            ("mine", "Mine Asteroid", self.mine),
            ("scan", "Scan Sector", self.scan),
            ("recharge", "Recharge Shields", self.recharge),
            ("repair", "Repair Hull", self.repair),
            ("jump", "Jump Home", self.jump_home),
            ("reset", "Restart", self.restart),
        ]

        for column, (name, text, command) in enumerate(specs):
            button = self.tk.Button(
                self.controls,
                text=text,
                command=command,
                bg="#1f2937",
                fg="#f9fafb",
                activebackground="#374151",
                activeforeground="#ffffff",
                relief="flat",
                padx=10,
                pady=10,
                font=("Segoe UI", 10, "bold"),
            )
            button.grid(row=0, column=column, sticky="ew", padx=4)
            self.controls.columnconfigure(column, weight=1)
            self.buttons[name] = button

        self.update_ui()

    def add_log(self, message: str) -> None:
        self.logs.append(message)
        self.logs = self.logs[-6:]

    def status_text(self) -> str:
        return (
            f"Turn {self.turn}    "
            f"Crystals {self.crystals}/{self.cargo_goal}    "
            f"Fuel {self.fuel}/{self.fuel_goal}    "
            f"Hull {self.hull}/{self.max_hull}    "
            f"Shield {self.shield}/{self.max_shield}"
        )

    def update_ui(self) -> None:
        self.status.configure(text=self.status_text())
        self.log_label.configure(text="\n".join(self.logs))

        can_repair = self.crystals >= 10 and self.hull < self.max_hull and not self.game_over
        can_jump = self.crystals >= self.cargo_goal and self.fuel >= self.fuel_goal and not self.game_over

        for name in ["mine", "scan", "recharge"]:
            self.buttons[name].configure(state="disabled" if self.game_over else "normal")
        self.buttons["repair"].configure(state="normal" if can_repair else "disabled")
        self.buttons["jump"].configure(state="normal" if can_jump else "disabled")
        self.buttons["reset"].configure(state="normal")

    def next_turn(self) -> None:
        self.turn += 1
        if self.scan_bonus > 0:
            self.scan_bonus -= 1

    def mine(self) -> None:
        if self.game_over:
            return

        gain = random.randint(4, 8) + (3 if self.scan_bonus else 0)
        self.crystals += gain
        self.fuel -= 1
        self.flash = 8
        self.add_log(f"Mining laser carved out {gain} crystals.")

        if random.random() < (0.18 if self.scan_bonus else 0.34):
            self.take_hit(random.randint(1, 2), "Rock shrapnel hit the ship.")
        elif random.random() < 0.20:
            found_fuel = random.randint(1, 2)
            self.fuel += found_fuel
            self.add_log(f"You found {found_fuel} fuel in an old probe tank.")

        if self.fuel < 0:
            self.take_hit(1, "The empty fuel cell forced a rough emergency burn.")

        self.next_turn()
        self.check_end()
        self.update_ui()

    def scan(self) -> None:
        if self.game_over:
            return

        self.scan_bonus = 2
        self.fuel = max(0, self.fuel - 1)
        self.add_log("Scanner mapped a safer mining path. The next mines are richer and safer.")

        if random.random() < 0.25:
            bonus = random.randint(1, 3)
            self.fuel += bonus
            self.add_log(f"The scan found a fuel pocket: +{bonus} fuel.")

        self.next_turn()
        self.check_end()
        self.update_ui()

    def recharge(self) -> None:
        if self.game_over:
            return

        fuel_gain = random.randint(2, 4)
        shield_gain = random.randint(1, 2)
        self.fuel += fuel_gain
        self.shield = min(self.max_shield, self.shield + shield_gain)
        self.add_log(f"Solar sails gathered +{fuel_gain} fuel and +{shield_gain} shield.")

        if random.random() < 0.18:
            self.take_hit(1, "A patrol drone clipped you during recharge.")

        self.next_turn()
        self.check_end()
        self.update_ui()

    def repair(self) -> None:
        if self.game_over or self.crystals < 10 or self.hull >= self.max_hull:
            return

        self.crystals -= 10
        repaired = min(2, self.max_hull - self.hull)
        self.hull += repaired
        self.add_log(f"Spent 10 crystals to weld the hull: +{repaired} hull.")
        self.next_turn()
        self.check_end()
        self.update_ui()

    def jump_home(self) -> None:
        if self.crystals < self.cargo_goal or self.fuel < self.fuel_goal or self.game_over:
            return

        self.game_over = True
        self.add_log("Jump drive online. You escaped the belt rich and alive. You win.")
        self.update_ui()

    def restart(self) -> None:
        self.reset_state()
        self.update_ui()

    def take_hit(self, damage: int, message: str) -> None:
        blocked = min(self.shield, damage)
        self.shield -= blocked
        damage -= blocked
        if damage > 0:
            self.hull -= damage
        if blocked:
            self.add_log(f"{message} Shield absorbed {blocked}.")
        if damage:
            self.add_log(f"Hull took {damage} damage.")

    def check_end(self) -> None:
        if self.hull <= 0:
            self.hull = 0
            self.game_over = True
            self.add_log("Hull breach. The mission is over.")
        elif self.fuel <= -3:
            self.game_over = True
            self.add_log("Fuel reserves collapsed. You drift too far from the jump lane.")

    def draw_scene(self) -> None:
        canvas = self.canvas
        canvas.delete("all")
        width = int(canvas.winfo_width() or 720)
        height = int(canvas.winfo_height() or 320)
        self.tick += 1

        for star in self.stars:
            star["x"] -= star["speed"]
            if star["x"] < 0:
                star["x"] = width
                star["y"] = random.randint(0, height)
            size = star["size"]
            canvas.create_oval(
                star["x"],
                star["y"],
                star["x"] + size,
                star["y"] + size,
                fill="#dbeafe",
                outline="",
            )

        asteroid_x = width - 150
        asteroid_y = height // 2 + int(18 * random.uniform(-0.4, 0.4))
        asteroid_color = "#6b7280" if not self.game_over else "#374151"
        canvas.create_oval(
            asteroid_x,
            asteroid_y - 46,
            asteroid_x + 92,
            asteroid_y + 46,
            fill=asteroid_color,
            outline="#9ca3af",
            width=2,
        )
        canvas.create_oval(asteroid_x + 18, asteroid_y - 18, asteroid_x + 38, asteroid_y + 2, fill="#4b5563", outline="")
        canvas.create_oval(asteroid_x + 52, asteroid_y + 8, asteroid_x + 72, asteroid_y + 28, fill="#4b5563", outline="")

        ship_y = height // 2 + int(8 * random.uniform(-0.5, 0.5))
        ship = [
            95,
            ship_y,
            165,
            ship_y - 34,
            220,
            ship_y,
            165,
            ship_y + 34,
        ]
        canvas.create_polygon(ship, fill="#38bdf8", outline="#e0f2fe", width=2)
        canvas.create_polygon(106, ship_y, 68, ship_y - 20, 88, ship_y, 68, ship_y + 20, fill="#f97316", outline="")

        if self.flash > 0:
            self.flash -= 1
            canvas.create_line(220, ship_y, asteroid_x, asteroid_y, fill="#facc15", width=4)

        if self.game_over:
            message = "YOU WIN" if self.crystals >= self.cargo_goal and self.fuel >= self.fuel_goal else "MISSION LOST"
            color = "#86efac" if message == "YOU WIN" else "#fca5a5"
            canvas.create_text(width // 2, 42, text=message, fill=color, font=("Segoe UI", 28, "bold"))
        else:
            canvas.create_text(
                width // 2,
                34,
                text="STAR MINER",
                fill="#bfdbfe",
                font=("Segoe UI", 24, "bold"),
            )

    def animate(self) -> None:
        self.draw_scene()
        self.root.after(60, self.animate)

    def run(self) -> None:
        self.build()
        self.animate()
        self.root.mainloop()


def run_game(program: Program) -> None:
    if program.game in {"star_miner", "starminer"}:
        StarMinerGame(program).run()
        return
    raise WindowScriptError(f"Unknown game: {program.game!r}")


def describe(program: Program) -> str:
    if program.game:
        return f"WindowScript OK: game={program.game!r}"

    handler_count = sum(1 for button in program.buttons if button.actions)
    return (
        f"WindowScript OK: title={program.title!r}, "
        f"numbers={len(program.numbers)}, texts={len(program.texts)}, "
        f"text_numbers={len(program.text_and_numbers)}, inputs={len(program.inputs)}, "
        f"messages={len(program.messages)}, progress={len(program.progress_bars)}, "
        f"buttons={len(program.buttons)}, handlers={handler_count}, "
        f"score_rules={len(program.score_rules)}"
    )


def main(argv: list[str]) -> int:
    parser = argparse.ArgumentParser(description="Run a WindowScript .ws file.")
    parser.add_argument("file", type=Path, help="WindowScript file to run")
    parser.add_argument("--check", action="store_true", help="Parse only; do not open a window")
    args = parser.parse_args(argv)

    try:
        program = parse_file(args.file)
        if args.check:
            print(describe(program))
            return 0

        if program.game:
            run_game(program)
            return 0

        TkRuntime(program).run()
        return 0
    except WindowScriptError as exc:
        print(f"WindowScript error: {exc}", file=sys.stderr)
        return 1
    except OSError as exc:
        print(f"File error: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
