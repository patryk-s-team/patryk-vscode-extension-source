require game
require windowmaker
require math

windowmaker='createGameWindow'

Inside='Star Miner':
game='star_miner'
