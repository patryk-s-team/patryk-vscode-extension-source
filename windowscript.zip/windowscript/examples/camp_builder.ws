require windowmaker
require buttonmaker
require clickybundle
require math

windowmaker='createWindow1'

Inside='Camp Builder':
createText='Title'='Camp Builder'
createInput='Player'='Explorer'
createMessage='Log'='Type your name, then gather food and wood.'

createNumber='Health'=150
createNumber='Food'=3
createNumber='Wood'=0
createNumber='Day'=1

createTextAndNumber='Stats'='Day {Day} | {Player} | Health {Health} | Food {Food} | Wood {Wood}'
createProgress='Health'=0..150
createProgress='Wood'=0..12

createButton='Name'='Set name'
whenButtonPressed='Name'='setPlayerFromInput message:Welcome, {Player}.'

createButton='Forage'='Forage'
whenButtonPressed='Forage'='randomFind=1..4 changeFood+{Find} changeHealth-1 changeDay+1 message:{Player} found {Find} food.'

createButton='Chop'='Chop wood'
whenButtonPressed='Chop'='randomLogs=1..3 changeWood+{Logs} changeHealth-2 changeDay+1 message:{Player} chopped {Logs} wood.'

createButton='Rest'='Rest'
whenButtonPressed='Rest'='changeHealth+2 changeFood-1 changeDay+1 message:{Player} rested.'

whenHealth<='0':LOSE='You ran out of health.'
whenWood>='12':WIN='{Player} built a strong camp.'
