
require windowmaker
require buttonmaker
require clickybundle
require math

windowmaker='createWindow1'

Inside='Tiny Survival':
createNumber='Health'=7
createNumber='Food'=3
createNumber='Wood'=90000
createNumber='Day'=1

createTextAndNumber='Stats'='Day {Day} | Health {Health} | Food {Food} | Wood {Wood}'
createTextAndNumber='Goal'='Try to reach Wood 100000 before Health runs out.'

createButton='Forage'='Forage'
whenButtonPressed='Forage'='changeFood+2 changeHealth-0.6 changeDay+1'

createButton='Chop'='Chop wood'
whenButtonPressed='Chop'='changeWood+2 changeHealth-0.6 changeDay+1'

createButton='Rest'='Rest'
whenButtonPressed='Rest'='changeHealth+2 changeFood-0.6 changeDay+1'

whenWood='100000':END_WINDOW_SCRIPT
