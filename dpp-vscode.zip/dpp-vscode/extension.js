const fs = require("fs");
const path = require("path");
const vscode = require("vscode");
const { parseDpp, renderHtml } = require("./runtime/run-dpp");

function getCurrentDppDocument() {
  const editor = vscode.window.activeTextEditor;
  if (!editor) {
    throw new Error("Open a .dpp file first.");
  }

  const document = editor.document;
  if (document.languageId !== "dpp" && path.extname(document.fileName).toLowerCase() !== ".dpp") {
    throw new Error("The current file is not a D++ .dpp file.");
  }

  if (document.isUntitled) {
    throw new Error("Save the .dpp file before running it.");
  }

  return document;
}

async function runCurrentFile() {
  try {
    const document = getCurrentDppDocument();
    await document.save();

    const inputPath = document.fileName;
    const inputDir = path.dirname(inputPath);
    const outputDir = path.join(inputDir, "dpp-out");
    const outputPath = path.join(outputDir, `${path.basename(inputPath, ".dpp")}.html`);

    const app = parseDpp(document.getText());
    const html = renderHtml(app, { inputDir });

    fs.mkdirSync(outputDir, { recursive: true });
    fs.writeFileSync(outputPath, html, "utf8");

    await vscode.env.openExternal(vscode.Uri.file(outputPath));
    vscode.window.showInformationMessage(`D++ built ${outputPath}`);
  } catch (error) {
    vscode.window.showErrorMessage(error.message);
  }
}

function activate(context) {
  context.subscriptions.push(
    vscode.commands.registerCommand("dpp.runCurrentFile", runCurrentFile)
  );
}

function deactivate() {}

module.exports = {
  activate,
  deactivate
};
