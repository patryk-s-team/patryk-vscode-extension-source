const fs = require("fs");
const path = require("path");
const { spawn } = require("child_process");
const { pathToFileURL } = require("url");

function usage() {
  console.log("Usage: node dpp/run-dpp.js <file.dpp> [--open] [--out output.html]");
}

function splitStatements(source) {
  const statements = [];
  let current = "";
  let quote = null;

  for (let index = 0; index < source.length; index += 1) {
    const char = source[index];
    const next = source[index + 1] || "";

    if ((char === "\"" || char === "'") && current[current.length - 1] !== "\\") {
      quote = quote === char ? null : quote || char;
      current += char;
      continue;
    }

    const isPeriodSeparator = char === "." && (!next || /\s/.test(next));
    if (!quote && (char === "\n" || char === "," || char === ";" || isPeriodSeparator)) {
      const statement = current.trim();
      if (statement) {
        statements.push(statement);
      }
      current = "";
      continue;
    }

    current += char;
  }

  const statement = current.trim();
  if (statement) {
    statements.push(statement);
  }

  return statements;
}

function stripComment(line) {
  let quote = null;

  for (let index = 0; index < line.length - 1; index += 1) {
    const char = line[index];
    if ((char === "\"" || char === "'") && line[index - 1] !== "\\") {
      quote = quote === char ? null : quote || char;
    }

    if (!quote && char === "/" && line[index + 1] === "/") {
      return line.slice(0, index);
    }
  }

  return line;
}

function cleanValue(value) {
  const trimmed = value.trim();
  const first = trimmed[0];
  const last = trimmed[trimmed.length - 1];

  if ((first === "\"" && last === "\"") || (first === "'" && last === "'")) {
    return trimmed.slice(1, -1);
  }

  return trimmed;
}

function parseDpp(source) {
  const app = {
    windowName: "app",
    title: "D++ App",
    width: 800,
    height: 600,
    background: "#ffffff",
    elements: [],
    buttonActions: {}
  };

  const withoutComments = source
    .split(/\r?\n/)
    .map(stripComment)
    .join("\n");

  const statements = splitStatements(withoutComments);
  const errors = [];

  statements.forEach((statement, index) => {
    let match = statement.match(/^create\s+window\s+called\s+(.+?)\s+and\s+title\s+called\s+(.+)$/i);
    if (match) {
      app.windowName = cleanValue(match[1]);
      app.title = cleanValue(match[2]);
      return;
    }

    match = statement.match(/^set\s+resolution\s+to\s+(\d{2,5})\s*x\s*(\d{2,5})$/i);
    if (match) {
      app.width = Number(match[1]);
      app.height = Number(match[2]);
      return;
    }

    match = statement.match(/^create\s+button\s+that\s+says\s+(.+)$/i);
    if (match) {
      app.elements.push({
        type: "button",
        label: cleanValue(match[1])
      });
      return;
    }

    match = statement.match(/^create\s+text\s+that\s+says\s+(.+)$/i);
    if (match) {
      app.elements.push({
        type: "text",
        value: cleanValue(match[1])
      });
      return;
    }

    match = statement.match(/^create\s+input\s+called\s+(.+)$/i);
    if (match) {
      app.elements.push({
        type: "input",
        name: cleanValue(match[1])
      });
      return;
    }

    match = statement.match(/^create\s+image\s+from\s+(.+)$/i);
    if (match) {
      app.elements.push({
        type: "image",
        src: cleanValue(match[1])
      });
      return;
    }

    match = statement.match(/^set\s+background\s+to\s+(.+)$/i);
    if (match) {
      app.background = cleanValue(match[1]);
      return;
    }

    match = statement.match(/^when\s+button\s+(.+?)\s+is\s+clicked\s+say\s+(.+)$/i);
    if (match) {
      app.buttonActions[cleanValue(match[1])] = cleanValue(match[2]);
      return;
    }

    errors.push(`Line ${index + 1}: I do not understand "${statement}"`);
  });

  if (errors.length > 0) {
    const error = new Error(errors.join("\n"));
    error.dppErrors = errors;
    throw error;
  }

  return app;
}

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll("\"", "&quot;")
    .replaceAll("'", "&#039;");
}

function escapeScriptJson(value) {
  return JSON.stringify(value)
    .replaceAll("<", "\\u003c")
    .replaceAll(">", "\\u003e")
    .replaceAll("&", "\\u0026");
}

function toCssColor(value) {
  const color = String(value).trim();

  if (/^#[0-9a-f]{3,8}$/i.test(color)) {
    return color;
  }

  if (/^[a-z]+$/i.test(color)) {
    return color.toLowerCase();
  }

  if (/^(rgb|rgba|hsl|hsla)\([0-9.,% ]+\)$/i.test(color)) {
    return color;
  }

  return "#ffffff";
}

function toImageSrc(src, inputDir) {
  const value = String(src).trim();

  if (/^(https?:|data:|file:)/i.test(value)) {
    return value;
  }

  if (path.isAbsolute(value)) {
    return pathToFileURL(value).href;
  }

  if (!inputDir) {
    return value;
  }

  return pathToFileURL(path.resolve(inputDir, value)).href;
}

function renderElement(element, inputDir) {
  if (element.type === "button") {
    return `<button type="button" data-dpp-button="${escapeHtml(element.label)}">${escapeHtml(element.label)}</button>`;
  }

  if (element.type === "text") {
    return `<p class="dpp-text">${escapeHtml(element.value)}</p>`;
  }

  if (element.type === "input") {
    return `<label class="dpp-input"><span>${escapeHtml(element.name)}</span><input name="${escapeHtml(element.name)}" placeholder="${escapeHtml(element.name)}"></label>`;
  }

  if (element.type === "image") {
    return `<img class="dpp-image" src="${escapeHtml(toImageSrc(element.src, inputDir))}" alt="${escapeHtml(path.basename(element.src))}">`;
  }

  return "";
}

function renderHtml(app, options = {}) {
  const content = app.elements
    .map((element) => renderElement(element, options.inputDir))
    .filter(Boolean)
    .join("\n        ");
  const background = toCssColor(app.background);
  const buttonActions = escapeScriptJson(app.buttonActions);

  return `<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>${escapeHtml(app.title)}</title>
    <style>
      :root {
        color-scheme: light;
        font-family: Arial, sans-serif;
        background: #eff3f8;
        color: #111827;
      }

      body {
        min-height: 100vh;
        margin: 0;
        display: grid;
        place-items: center;
      }

      .dpp-window {
        width: min(${app.width}px, calc(100vw - 32px));
        min-height: min(${app.height}px, calc(100vh - 32px));
        background: ${background};
        border: 1px solid #cbd5e1;
        box-shadow: 0 20px 55px rgba(15, 23, 42, 0.18);
      }

      .title-bar {
        height: 36px;
        display: flex;
        align-items: center;
        gap: 8px;
        padding: 0 12px;
        background: #1f2937;
        color: #ffffff;
        font-size: 14px;
      }

      .dot {
        width: 10px;
        height: 10px;
        border-radius: 999px;
        background: #94a3b8;
      }

      .content {
        display: flex;
        flex-wrap: wrap;
        align-items: flex-start;
        gap: 10px;
        padding: 16px;
      }

      .dpp-text {
        flex-basis: 100%;
        margin: 0;
        font-size: 18px;
        line-height: 1.4;
      }

      .dpp-input {
        display: grid;
        gap: 6px;
        min-width: 190px;
        color: #334155;
        font-size: 13px;
      }

      input {
        min-height: 36px;
        padding: 0 10px;
        border: 1px solid #94a3b8;
        background: rgba(255, 255, 255, 0.9);
        color: #111827;
        font: inherit;
      }

      .dpp-image {
        max-width: 100%;
        max-height: 260px;
        object-fit: contain;
        border: 1px solid rgba(15, 23, 42, 0.12);
      }

      button {
        min-width: 88px;
        min-height: 36px;
        padding: 0 14px;
        border: 1px solid #64748b;
        background: #f8fafc;
        color: #111827;
        cursor: pointer;
        font: inherit;
      }

      button:hover {
        background: #e2e8f0;
      }
    </style>
  </head>
  <body>
    <main class="dpp-window" aria-label="${escapeHtml(app.windowName)}">
      <header class="title-bar">
        <span class="dot"></span>
        <strong>${escapeHtml(app.title)}</strong>
      </header>
      <section class="content">
        ${content || ""}
      </section>
    </main>
    <script>
      const dppButtonActions = ${buttonActions};

      document.querySelectorAll("[data-dpp-button]").forEach((button) => {
        const message = dppButtonActions[button.dataset.dppButton];
        if (!message) {
          return;
        }

        button.addEventListener("click", () => {
          alert(message);
        });
      });
    </script>
  </body>
</html>
`;
}

function openFile(filePath) {
  const absolute = path.resolve(filePath);

  if (process.platform === "win32") {
    spawn("cmd", ["/c", "start", "", absolute], {
      detached: true,
      stdio: "ignore"
    }).unref();
    return;
  }

  const command = process.platform === "darwin" ? "open" : "xdg-open";
  spawn(command, [absolute], {
    detached: true,
    stdio: "ignore"
  }).unref();
}

function main() {
  const args = process.argv.slice(2);
  const input = args.find((arg) => !arg.startsWith("--"));

  if (!input || args.includes("--help") || args.includes("-h")) {
    usage();
    process.exit(input ? 0 : 1);
  }

  const outIndex = args.indexOf("--out");
  const output = outIndex >= 0
    ? args[outIndex + 1]
    : path.join(__dirname, "out", `${path.basename(input, path.extname(input))}.html`);

  if (outIndex >= 0 && !output) {
    console.error("Missing output path after --out.");
    process.exit(1);
  }

  const source = fs.readFileSync(input, "utf8");
  const app = parseDpp(source);
  const html = renderHtml(app, {
    inputDir: path.dirname(path.resolve(input))
  });
  const outputPath = path.resolve(output);

  fs.mkdirSync(path.dirname(outputPath), { recursive: true });
  fs.writeFileSync(outputPath, html, "utf8");

  console.log(`Built ${outputPath}`);

  if (args.includes("--open")) {
    openFile(outputPath);
  }
}

if (require.main === module) {
  try {
    main();
  } catch (error) {
    console.error(error.message);
    process.exit(1);
  }
}

module.exports = {
  parseDpp,
  renderHtml
};
