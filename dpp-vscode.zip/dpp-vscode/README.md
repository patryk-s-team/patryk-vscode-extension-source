# D++ For VS Code

This is the D++ VS Code extension. It supports `.dpp` syntax highlighting and can run the current `.dpp` file.

## Run A D++ File

Open a `.dpp` file, then run:

```text
Ctrl+Shift+P
D++: Run Current D++ File
```

The extension builds an HTML app beside your `.dpp` file in a `dpp-out` folder and opens it.

## Install With The D++ Installer

Use the `dpp-installer` folder instead of copying this folder by hand.
